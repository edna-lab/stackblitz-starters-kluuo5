export class Livro
  {
    constructor(
      public id: number,
      public name: string,
      public type: string,
      public description: string,
      public year: number
    ){}
  }